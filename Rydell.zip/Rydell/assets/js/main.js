document.addEventListener('DOMContentLoaded', function() {
    // Modal Elements
    const customerAuthModal = document.getElementById('customer-auth-modal');
    const restaurantAuthModal = document.getElementById('restaurant-auth-modal');
    const closeButtons = document.querySelectorAll('.close');
    
    // Button Elements
    const customerLoginBtn = document.getElementById('customer-login-btn');
    const customerSignupBtn = document.getElementById('customer-signup-btn');
    const restaurantLoginBtn = document.getElementById('restaurant-login-btn');
    const restaurantSignupBtn = document.getElementById('restaurant-signup-btn');
    
    // Tab Elements
    const tabButtons = document.querySelectorAll('.tab-btn');
    
    // Form Elements
    const customerLoginForm = document.getElementById('customer-login-form');
    const customerSignupForm = document.getElementById('customer-signup-form');
    const restaurantLoginForm = document.getElementById('restaurant-login-form');
    const restaurantSignupForm = document.getElementById('restaurant-signup-form');
    
    // Open Customer Auth Modal
    customerLoginBtn.addEventListener('click', function() {
        customerAuthModal.style.display = 'block';
        showTab('customer-login');
    });
    
    customerSignupBtn.addEventListener('click', function() {
        customerAuthModal.style.display = 'block';
        showTab('customer-signup');
    });
    
    // Open Restaurant Auth Modal
    restaurantLoginBtn.addEventListener('click', function() {
        restaurantAuthModal.style.display = 'block';
        showTab('restaurant-login');
    });
    
    restaurantSignupBtn.addEventListener('click', function() {
        restaurantAuthModal.style.display = 'block';
        showTab('restaurant-signup');
    });
    
    // Close Modals
    closeButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            customerAuthModal.style.display = 'none';
            restaurantAuthModal.style.display = 'none';
        });
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === customerAuthModal) {
            customerAuthModal.style.display = 'none';
        }
        if (event.target === restaurantAuthModal) {
            restaurantAuthModal.style.display = 'none';
        }
    });
    
    // Tab Functionality
    tabButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            showTab(tabId);
        });
    });
    
    function showTab(tabId) {
        // Get all tab content elements in the same modal as the tab
        const modal = document.getElementById(tabId).closest('.modal');
        const tabContents = modal.querySelectorAll('.tab-content');
        const tabBtns = modal.querySelectorAll('.tab-btn');
        
        // Hide all tab contents
        tabContents.forEach(function(content) {
            content.classList.remove('active');
        });
        
        // Remove active class from all tab buttons
        tabBtns.forEach(function(btn) {
            btn.classList.remove('active');
        });
        
        // Show the selected tab content
        document.getElementById(tabId).classList.add('active');
        
        // Add active class to the clicked tab button
        modal.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
    }
    
    // Form Submissions
    if (customerLoginForm) {
        customerLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('customer-login-email').value;
            const password = document.getElementById('customer-login-password').value;
            
            // Create form data
            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            formData.append('user_type', 'customer');

            // Send login request
            fetch('/smart rest/login-handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.redirected) {
                    window.location.href = response.url;
                }
            })
            .catch(error => {
                console.error('Login error:', error);
                alert('Login failed. Please try again.');
            });
        });
    }
    
    if (customerSignupForm) {
        customerSignupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const name = document.getElementById('customer-name').value;
            const email = document.getElementById('customer-email').value;
            const phone = document.getElementById('customer-phone').value;
            const address = document.getElementById('customer-address').value;
            const password = document.getElementById('customer-password').value;
            const confirmPassword = document.getElementById('customer-confirm-password').value;
            
            // Password validation
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('name', name);
            formData.append('email', email);
            formData.append('phone', phone);
            formData.append('address', address);
            formData.append('password', password);
            formData.append('user_type', 'customer');

            // Send registration request
            fetch('/smart rest/register-handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.redirected) {
                    window.location.href = response.url;
                }
            })
            .catch(error => {
                console.error('Registration error:', error);
                alert('Registration failed. Please try again.');
            });
        });
    }
    
    if (restaurantLoginForm) {
        restaurantLoginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = document.getElementById('restaurant-login-email').value;
            const password = document.getElementById('restaurant-login-password').value;
            
            // Create form data
            const formData = new FormData();
            formData.append('email', email);
            formData.append('password', password);
            formData.append('user_type', 'restaurant');

            // Send login request
            fetch('/smart rest/login-handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.redirected) {
                    window.location.href = response.url;
                }
            })
            .catch(error => {
                console.error('Login error:', error);
                alert('Login failed. Please try again.');
            });
        });
    }
    
    if (restaurantSignupForm) {
        restaurantSignupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const restaurantName = document.getElementById('restaurant-name').value;
            const ownerName = document.getElementById('owner-name').value;
            const email = document.getElementById('restaurant-email').value;
            const phone = document.getElementById('restaurant-phone').value;
            const address = document.getElementById('restaurant-address').value;
            const cuisineType = document.getElementById('cuisine-type').value;
            const description = document.getElementById('restaurant-description').value;
            const password = document.getElementById('restaurant-password').value;
            const confirmPassword = document.getElementById('restaurant-confirm-password').value;
            
            // Password validation
            if (password !== confirmPassword) {
                alert('Passwords do not match!');
                return;
            }
            
            // Cuisine type validation
            if (cuisineType === '') {
                alert('Please select a cuisine type!');
                return;
            }
            
            // Create form data
            const formData = new FormData();
            formData.append('restaurant_name', restaurantName);
            formData.append('owner_name', ownerName);
            formData.append('email', email);
            formData.append('phone', phone);
            formData.append('address', address);
            formData.append('cuisine_type', cuisineType);
            formData.append('description', description);
            formData.append('password', password);
            formData.append('user_type', 'restaurant');

            // Send registration request
            fetch('/smart rest/register-handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.redirected) {
                    window.location.href = response.url;
                }
            })
            .catch(error => {
                console.error('Registration error:', error);
                alert('Registration failed. Please try again.');
            });
        });
    }
});