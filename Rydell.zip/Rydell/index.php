<?php 
session_start();
require_once 'includes/auth.php'; 

// Helper to get form data and clear it
function get_form_data($field, $form_type = 'signup') {
    $session_key = ($form_type === 'login') ? 'login_form_data' : 'form_data';
    if (isset($_SESSION[$session_key][$field])) {
        return htmlspecialchars($_SESSION[$session_key][$field]);
    }
    return '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodiFusion - Smart Restaurant Aggregator</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Header Section -->
    <header>
        <div class="container">
            <div class="logo">
                <i class="fas fa-utensils"></i>
                <h1>FoodiFusion</h1>
            </div>
            <nav>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#" id="customer-login-btn">Customer Login</a></li>
                    <li><a href="#" id="restaurant-login-btn" class="btn-primary">Restaurant Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1>Smart Restaurant Platform</h1>
            <p>Connecting restaurants with customers through AI-powered recommendations</p>
            
            <div class="cards">
                <!-- Restaurant Card -->
                <div class="card restaurant-card">
                    <h2>For Restaurants</h2>
                    <p>Join our platform to reach more customers, manage orders efficiently, and grow your business.</p>
                    <ul>
                        <li><i class="fas fa-chart-line"></i> Real-time analytics</li>
                        <li><i class="fas fa-utensils"></i> Easy menu management</li>
                        <li><i class="fas fa-star"></i> Customer reviews</li>
                    </ul>
                    <button id="restaurant-signup-btn">Join as Restaurant</button>
                </div>
                
                <!-- Customer Card -->
                <div class="card customer-card">
                    <h2>For Customers</h2>
                    <p>Discover restaurants that match your preferences, dietary needs, and location.</p>
                    <ul>
                        <li><i class="fas fa-brain"></i> AI-powered recommendations</li>
                        <li><i class="fas fa-leaf"></i> Dietary preference matching</li>
                        <li><i class="fas fa-map-marker-alt"></i> Location-based suggestions</li>
                    </ul>
                    <button id="customer-signup-btn">Sign Up as Customer</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <h2>Smart Features</h2>
            <div class="feature-cards">
                <div class="feature">
                    <i class="fas fa-map-marker-alt"></i>
                    <h3>Location-Based</h3>
                    <p>Find restaurants near you with accurate delivery time estimates</p>
                </div>
                <div class="feature">
                    <i class="fas fa-utensils"></i>
                    <h3>Dietary Matching</h3>
                    <p>Filter restaurants based on your dietary preferences and allergies</p>
                </div>
                <div class="feature">
                    <i class="fas fa-brain"></i>
                    <h3>Personalized</h3>
                    <p>Get recommendations that learn from your order history</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Error Message Display -->
    <?php if (isset($_GET['error'])): ?>
    <div class="error-message" style="background: #ffebee; color: #c62828; padding: 10px; margin: 10px; border-radius: 4px; text-align: center;">
        <?php echo htmlspecialchars($_GET['error']); ?>
    </div>
    <?php endif; ?>

    <!-- Customer Authentication Modal -->
    <div id="customer-auth-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="tabs">
                <button class="tab-btn active" data-tab="customer-login">Login</button>
                <button class="tab-btn" data-tab="customer-signup">Sign Up</button>
            </div>
            
            <!-- Customer Login Form -->
                        <div id="customer-login" class="tab-content active">
                <?php
                if (isset($_SESSION['login_errors'])) {
                    echo '<div class="errors">';
                    foreach ($_SESSION['login_errors'] as $error) {
                        echo '<p>' . htmlspecialchars($error) . '</p>';
                    }
                    echo '</div>';
                }
                ?>
                <h2>Customer Login</h2>
                <form id="customer-login-form" method="post" action="login-handler.php">
                    <div class="form-group">
                        <label for="customer-login-email">Email</label>
                                                <input type="email" id="customer-login-email" name="email" required value="<?php echo get_form_data('email', 'login'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="customer-login-password">Password</label>
                        <input type="password" id="customer-login-password" name="password" required>
                        <input type="hidden" name="user_type" value="customer">
                    </div>
                    <button type="submit" class="btn-primary">Login</button>
                </form>
            </div>
            
            <!-- Customer Signup Form -->
            <div id="customer-signup" class="tab-content">
                <h2>Customer Sign Up</h2>
                <?php
                if (isset($_SESSION['errors'])) {
                    echo '<div class="errors">';
                    foreach ($_SESSION['errors'] as $error) {
                        echo '<p>' . htmlspecialchars($error) . '</p>';
                    }
                    echo '</div>';
                    unset($_SESSION['errors']);
                    unset($_SESSION['form_data']);
                }
                ?>
                <form id="customer-signup-form" method="post" action="register-handler.php">
                    <div class="form-group">
                        <label for="customer-name">Full Name</label>
                        <input type="text" id="customer-name" name="name" placeholder="Full Name" required value="<?php echo get_form_data('name'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="customer-email">Email</label>
                        <input type="email" id="customer-email" name="email" placeholder="Email" required value="<?php echo get_form_data('email'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="customer-phone">Phone</label>
                        <input type="tel" id="customer-phone" name="phone" placeholder="Phone (+237...)" required pattern="^\+237[6,2][0-9]{8}$" title="Phone number must be in the format +237XXXXXXXXX" value="<?php echo get_form_data('phone'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="customer-address">Address</label>
                        <textarea id="customer-address" name="address" placeholder="Address" required><?php echo get_form_data('address'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="customer-password">Password</label>
                        <input type="password" id="customer-password" name="password" placeholder="Password" required minlength="8" title="Password must be at least 8 characters long">
                        <input type="hidden" name="user_type" value="customer">
                    </div>
                    <div class="form-group">
                        <label for="customer-confirm-password">Confirm Password</label>
                        <input type="password" id="customer-confirm-password" required>
                    </div>
                    <button type="submit" class="btn-primary">Sign Up</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Restaurant Authentication Modal -->
    <div id="restaurant-auth-modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="tabs">
                <button class="tab-btn active" data-tab="restaurant-login">Login</button>
                <button class="tab-btn" data-tab="restaurant-signup">Register</button>
            </div>
            
            <!-- Restaurant Login Form -->
                        <div id="restaurant-login" class="tab-content active">
                <?php
                if (isset($_SESSION['login_errors'])) {
                    echo '<div class="errors">';
                    foreach ($_SESSION['login_errors'] as $error) {
                        echo '<p>' . htmlspecialchars($error) . '</p>';
                    }
                    echo '</div>';
                }
                ?>
                <h2>Restaurant Login</h2>
                <form id="restaurant-login-form" method="post" action="/smart%20rest/login-handler.php">
                    <div class="form-group">
                        <label for="restaurant-login-email">Email</label>
                                                <input type="email" id="restaurant-login-email" name="email" required value="<?php echo get_form_data('email', 'login'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="restaurant-login-password">Password</label>
                        <input type="password" id="restaurant-login-password" name="password" required>
                        <input type="hidden" name="user_type" value="restaurant">
                    </div>
                    <button type="submit" class="btn-primary">Login</button>
                </form>
            </div>
            
            <!-- Restaurant Signup Form -->
            <div id="restaurant-signup" class="tab-content">
                <h2>Restaurant Registration</h2>
                <form id="restaurant-signup-form" method="post" action="register-handler.php">
                    <div class="form-group">
                        <label for="restaurant-name">Restaurant Name</label>
                        <input type="text" id="restaurant-name" name="restaurant_name" placeholder="Restaurant Name" required value="<?php echo get_form_data('restaurant_name'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="owner-name">Owner Name</label>
                        <input type="text" id="owner-name" name="name" placeholder="Full Name" required value="<?php echo get_form_data('name'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="restaurant-email">Email</label>
                        <input type="email" id="restaurant-email" name="email" placeholder="Email" required value="<?php echo get_form_data('email'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="restaurant-phone">Phone</label>
                        <input type="tel" id="restaurant-phone" name="phone" placeholder="Phone (+237...)" required pattern="^\+237[6,2][0-9]{8}$" title="Phone number must be in the format +237XXXXXXXXX" value="<?php echo get_form_data('phone'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="restaurant-address">Address</label>
                        <textarea id="restaurant-address" name="address" placeholder="Address" required><?php echo get_form_data('address'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="cuisine-type">Cuisine Type</label>
                        <select id="cuisine-type" name="cuisine_type" required>
                            <option value="">Select Cuisine Type</option>
                            <option value="italian">Italian</option>
                            <option value="chinese">Chinese</option>
                            <option value="mexican">Mexican</option>
                            <option value="indian">Indian</option>
                            <option value="japanese">Japanese</option>
                            <option value="american">American</option>
                            <option value="african">African</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="restaurant-description">Description</label>
                        <textarea id="restaurant-description" name="description" placeholder="Description" required><?php echo get_form_data('description'); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="restaurant-password">Password</label>
                        <input type="password" id="restaurant-password" name="password" placeholder="Password" required minlength="8" title="Password must be at least 8 characters long">
                        <input type="hidden" name="user_type" value="restaurant">
                    </div>
                    <div class="form-group">
                        <label for="restaurant-confirm-password">Confirm Password</label>
                        <input type="password" id="restaurant-confirm-password" required>
                    </div>
                    <button type="submit" class="btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p>&copy; 2023 FoodiFusion. All rights reserved.</p>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>